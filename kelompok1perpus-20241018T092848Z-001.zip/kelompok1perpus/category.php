<!doctype html>
<html class="no-js" lang="en">

<head>
	<meta charset="utf-8">

	<!--====== Title ======-->
	<title>Category | ClassiList Classified Ads Template</title>

	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--====== Favicon Icon ======-->
	<link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

	<!--====== Animate CSS ======-->
	<link rel="stylesheet" href="assets/css/animate.css">

	<!--====== Tiny slider CSS ======-->
	<link rel="stylesheet" href="assets/css/tiny-slider.css">

	<!--====== glightbox CSS ======-->
	<link rel="stylesheet" href="assets/css/glightbox.min.css">

	<!--====== Line Icons CSS ======-->
	<link rel="stylesheet" href="assets/css/LineIcons.2.0.css">

	<!--====== Selectr CSS ======-->
	<link rel="stylesheet" href="assets/css/selectr.css">

	<!--====== Nouislider CSS ======-->
	<link rel="stylesheet" href="assets/css/nouislider.css">

	<!--====== Bootstrap CSS ======-->
	<link rel="stylesheet" href="assets/css/bootstrap-5.0.5-alpha.min.css">

	<!--====== Style CSS ======-->
	<link rel="stylesheet" href="assets/css/style.css">


</head>

<body>
	<!--[if IE]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

	<!--====== PRELOADER PART START ======-->

	<div class="preloader">
		<div class="loader">
			<div class="ytp-spinner">
				<div class="ytp-spinner-container">
					<div class="ytp-spinner-rotator">
						<div class="ytp-spinner-left">
							<div class="ytp-spinner-circle"></div>
						</div>
						<div class="ytp-spinner-right">
							<div class="ytp-spinner-circle"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!--====== PRELOADER PART ENDS ======-->

	<!--====== HEADER PART START ======-->

	<header class="header_area">
		<div id="header_navbar" class="header_navbar">
			<div class="container position-relative">
				<div class="row align-items-center">
					<div class="col-xl-12">
						<nav class="navbar navbar-expand-lg">
							<a class="navbar-brand" href="index.html">
								<img id="logo" src="assets/images/logo/logo.svg" alt="Logo">
							</a>
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
								aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
								<span class="toggler-icon"></span>
								<span class="toggler-icon"></span>
								<span class="toggler-icon"></span>
							</button>
							<div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
								<ul id="nav" class="navbar-nav">
									<li class="nav-item">
										<a class="page-scroll" href="index.html">Home</a>
									</li>
									<li class="nav-item">
										<a class="page-scroll active" data-toggle="collapse" data-target="#sub-nav1" aria-controls="sub-nav1"
											aria-expanded="false" aria-label="Toggle navigation" href="javascript:void(0)">Pages
											<div class="sub-nav-toggler">
												<span></span>
											</div>
										</a>
										<ul class="sub-menu collapse" id="sub-nav1">
											<li><a href="about.html">About</a></li>
											<li><a href="service.html">Service</a></li>
											<li><a href="category-list.html">Category List</a></li>
											<li><a href="category.html" class="active">Category Grid</a></li>
											<li><a href="pricing.html">Pricing</a></li>
											<li><a href="accordions.html">Accordions</a></li>
											<li><a href="product-details.html">Product Details</a></li>
											<li><a href="login.html">Login</a></li>
											<li><a href="signup.html">Sign Up</a></li>
											<li><a href="404.html">404 Page</a></li>
										</ul>
									</li>
									<li class="nav-item">
										<a class="page-scroll active" data-toggle="collapse" data-target="#sub-nav" aria-controls="sub-nav"
											aria-expanded="false" aria-label="Toggle navigation" href="javascript:void(0)">Category
											<div class="sub-nav-toggler">
												<span></span>
											</div>
										</a>
										<ul class="sub-menu collapse" id="sub-nav">
											<li><a href="category.html">Category Grid</a></li>
											<li><a href="category-list.html" class="active">Category List</a></li>
										</ul>
									</li>
									<li class="nav-item">
										<a class="page-scroll" href="product-details.html">Product Details</a>
									</li>
								</ul>
							</div>
							<ul class="header-btn d-md-flex">
								<li>
									<a href="#" class="main-btn account-btn">
										<span class="d-md-none"><i class="lni lni-user"></i></span>
										<span class="d-none d-md-block">My Account</span>
									</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard.html">Dashboard</a></li>
										<li><a href="profile-settings.html">Profile Settings</a></li>
										<li><a href="post-ad.html">Post Ad</a></li>
										<li><a href="my-ads.html">My Ads</a></li>
										<li><a href="offers.html">Offers/Messages</a></li>
										<li><a href="payments.html">Payments</a></li>
										<li><a href="favorites.html">Favorites</a></li>
										<li><a href="privacy.html">Privacy</a></li>
										<li><a href="javascript:void(0)">Sign Out</a></li>
									</ul>
								</li>
								<li>
									<a href="post-ad.html" class="main-btn btn-hover d-none d-md-block">Post An Ad</a>
								</li>
							</ul>
						</nav> <!-- navbar -->
					</div>
				</div> <!-- row -->
			</div> <!-- container -->
		</div> <!-- header navbar -->
	</header>

	<!--====== HEADER PART ENDS ======-->

	<!--====== BANNER PART START ======-->
	<section class="banner-area bg_cover">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="banner-content">
						<h1 class="text-white">All Categories</h1>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="index.html">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Category</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--====== BANNER PART END ======-->


	<!--====== CATEGORY PART START ======-->
	<section class="category-area pb-110">
		<div class="container">
			<!-- category top -->
			<div class="category-top box-style">
				<div class="row align-items-center">

					<div class="col-md-6">
						<div class="left-wrapper">
							<div class="sorting">
								<label for="sort">Show items</label>
								<select name="sort" id="sort">
									<option value="0">Popular Items</option>
									<option value="1">By Default</option>
									<option value="2">Newest Items</option>
								</select>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="right-wrapper">
							
							<ul class="nav product-view-btns" id="myTab" role="tablist">
								<li class="product-view-item" role="presentation">
									<a class="product-view-btn" id="list-tab" data-toggle="tab" href="#list" role="tab" aria-controls="list"
										aria-selected="true"><i class="lni lni-list"></i></a>
								</li>
								<li class="product-view-item" role="presentation">
									<a class="product-view-btn active" id="grid-tab" data-toggle="tab" href="#grid" role="tab" aria-controls="grid"
										aria-selected="false"><i class="lni lni-grid-alt"></i></a>
								</li>
							</ul>

							<form action="#">
								<input type="text" name="search" id="search" placeholder="Search">
								<button><i class="lni lni-search-alt"></i></button>
							</form>
						</div>
					</div>

				</div>
			</div>

			<!-- category wrapper -->
			<div class="category-wrapper">
				<div class="row">

					<!-- left-wrapper  -->
					<div class="col-lg-8">
						<div class="left-wrapper">


							<div class="tab-content" id="myTabContent">
								<div class="tab-pane fade show active" id="grid" role="tabpanel" aria-labelledby="grid-tab">

									<div class="row">
									
										<div class="col-lg-6 col-md-6">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-1.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Apple iPhone x</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$120.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-6 col-md-6">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-2.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Apple MacBook Air</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$420.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-6 col-md-6">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-3.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Cctv camera</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$80.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-6 col-md-6">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-4.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Apple's new iMac</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$3000.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-6 col-md-6">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-5.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Best Compact DSLR</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$290.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-6 col-md-6">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-6.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">10 Future Concept Cars</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$4520.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
									</div>

								</div>


								<div class="tab-pane fade" id="list" role="tabpanel" aria-labelledby="list-tab">

									<div class="row">
									
										<div class="col-lg-12">
											<div class="single-product list-view">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-1.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Apple iPhone x</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$120.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-12">
											<div class="single-product list-view">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-2.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Apple MacBook Air</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$420.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-12">
											<div class="single-product list-view">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-3.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Cctv camera</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$80.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-12">
											<div class="single-product list-view">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-4.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Apple's new iMac</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$3000.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-12">
											<div class="single-product list-view">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-5.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">Best Compact DSLR</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$290.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
										<div class="col-lg-12">
											<div class="single-product list-view">
												<div class="product-img">
													<a href="product-details.html">
														<img src="assets/images/product/l-product-6.jpg" alt="">
													</a>
													<div class="product-action">
														<a href="javascript:void(0)"><i class="lni lni-heart"></i></a>
														<a href="javascript:void(0)" class="share"><i class="lni lni-share"></i></a>
													</div>
												</div>
									
												<div class="product-content">
													<h3 class="name"><a href="product-details.html">10 Future Concept Cars</a></h3>
													<span class="update">Last Update: 5 hours ago</span>
													<ul class="address">
														<li>
															<a href="javascript:void(0)"><i class="lni lni-calendar"></i> 20 June, 2023</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-map-marker"></i> Canada</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-user"></i> Stifen Jon</a>
														</li>
														<li>
															<a href="javascript:void(0)"><i class="lni lni-package"></i> Used</a>
														</li>
													</ul>
													<div class="product-bottom">
														<h3 class="price">$4520.99</h3>
														<a href="javascript:void(0)" class="link-ad"><i class="lni lni-checkmark-circle"></i> Verified Ad</a>
													</div>
												</div>
											</div>
										</div>
									
									</div>

								</div>
							</div>


							
						</div>
					</div>

					<!-- sidebar wrapper  -->
					<div class="col-lg-4">
						<div class="sidebar-wrapper">
							<!-- price range  -->
							<div class="box-style price-range">
								<h3 class="mb-30">Price Range</h3>
								<div class="collapse show" id="pricingOne">
									<div class="price-range">
										<div class="price-amount">
											<div class="amount-input">
												<label>Minimum Price</label>
												<div id="slider-snap-value-lower" class="amount" contenteditable></div>
											</div>
											<div class="amount-input">
												<label>Maximum Price</label>
												<div id="slider-snap-value-upper" class="amount" contenteditable></div>
											</div>
										</div>
										<div class="range-slider" id="slider-snap"></div>
									</div>
								</div>
							</div>

							<!-- sidebar category  -->
							<div class="box-style sidebar-category">
								<h3 class="mb-30">All Categories</h3>
								<ul>
									<li><a href="javascript:void(0)"><span>Web Design</span> <span class="right">12</span></a></li>
									<li><a href="javascript:void(0)"><span>Branding</span> <span class="right">20</span></a></li>
									<li><a href="javascript:void(0)"><span>Web Development</span> <span class="right">45</span></a></li>
									<li><a href="javascript:void(0)"><span>Graphic Design</span> <span class="right">87</span></a></li>
									<li><a href="javascript:void(0)"><span>Marketing</span> <span class="right">35</span></a></li>
									<li><a href="javascript:void(0)"><span>Wireframing</span> <span class="right">34</span></a></li>
								</ul>
							</div>

							<!-- add box -->
							<div class="box-style add-box">
								<h3 class="mb-30">Advertisement</h3>
								<div class="image">
									<a href="javascript:void(0)" class="d-block">
										<img src="assets/images/product/ad-img.jpg" alt="" class="w-100">
									</a>
								</div>
							</div>

							<!-- social box -->
							<div class="box-style social-box">
								<h3 class="mb-30">Follow Us</h3>

								<ul class="social">
									<li><a href="javascript:void(0)"><i class="lni lni-facebook-filled"></i></a></li>
									<li><a href="javascript:void(0)"><i class="lni lni-twitter-filled"></i></a></li>
									<li><a href="javascript:void(0)"><i class="lni lni-instagram-filled"></i></a></li>
									<li><a href="javascript:void(0)"><i class="lni lni-linkedin-original"></i></a></li>
								</ul>
							</div>

						</div>
					</div>

				</div>
			</div>

		</div>
	</section>
	<!--====== CATEGORY PART END ======-->

				<div class="mx-auto col-lg-9 col-xl-9 col-md-10 pt-60 mb-60">
					<div class="text-center hero-content">
						<h1 class="mb-30 wow fadeInUp" data-wow-delay=".2s">You are using free lite version</h1>
						<p class="wow fadeInUp" data-wow-delay=".4s">Please, purchase full version to get all pages, features and sections.</p></br>

						<a href="https://rebrand.ly/gg-classilist/" rel="nofollow" class="main-btn btn-hover">Purchase Now</a>

					</div>

	<!--====== FOOTER PART START ======-->
	<footer class="footer-area">
		<div class="widget-wrapper">
			<div class="map-img">
				<img src="assets/images/footer/map-img.svg" alt="">
			</div>
			<div class="container">
				<div class="row">

					<div class="col-xl-4 col-md-7">
						<div class="footer-widget about">
							<a href="index.html" class="d-inline-block mb-30">
								<img src="assets/images/logo/logo.svg" alt="">
							</a>
							<p class="text-white mb-25">Buy And Sell Everything From Used Cars To Mobile Phones And Computers, Search For Property, Jobs And More</p>
							<ul class="social">
								<li><a href="javascript:void(0)"><i class="lni lni-facebook-filled"></i></a></li>
								<li><a href="javascript:void(0)"><i class="lni lni-twitter-filled"></i></a></li>
								<li><a href="javascript:void(0)"><i class="lni lni-instagram-filled"></i></a></li>
								<li><a href="javascript:void(0)"><i class="lni lni-linkedin-original"></i></a></li>
							</ul>
						</div>
					</div>

					<div class="col-xl-2 col-md-4 order-md-2 order-xl-1 col-sm-6">
						<div class="footer-widget">
							<h4>Quick Link</h4>
							<ul class="link">
								<li><a href="javascript:void(0)">Home</a></li>
								<li><a href="javascript:void(0)">About</a></li>
								<li><a href="javascript:void(0)">Category</a></li>
								<li><a href="javascript:void(0)">Product details</a></li>
								<li><a href="javascript:void(0)">Contact</a></li>
							</ul>
						</div>
					</div>

					<div class="col-xl-2 col-md-4 order-md-3 order-xl-2 col-sm-6">
						<div class="footer-widget">
							<h4>Support</h4>
							<ul class="link">
								<li><a href="javascript:void(0)">Live Chat</a></li>
								<li><a href="javascript:void(0)">Privacy Policy</a></li>
								<li><a href="javascript:void(0)">Purchase</a></li>
								<li><a href="javascript:void(0)">Protection</a></li>
								<li><a href="javascript:void(0)">Support</a></li>
							</ul>
						</div>
					</div>

					<div class="col-xl-2 col-md-4 order-md-4 order-xl-3 col-sm-6">
						<div class="footer-widget">
							<h4>Information</h4>
							<ul class="link">
								<li><a href="javascript:void(0)">Company</a></li>
								<li><a href="javascript:void(0)">Contact Info</a></li>
								<li><a href="javascript:void(0)">Blog & Articles</a></li>
								<li><a href="javascript:void(0)">Terms of Service</a></li>
								<li><a href="javascript:void(0)">Privacy Policy</a></li>
							</ul>
						</div>
					</div>

					<div class="col-xl-2 col-md-5 order-md-1 order-xl-4 col-sm-6">
						<div class="footer-widget">
							<h4>Contact Us</h4>
							<ul>
								<li>
									<span>Phone:</span>
									0345983672937
								</li>
								<li>
									<span>Email:</span>
									yourmail@gmail.com
								</li>
								<li>
									<span>Location:</span>
									United State of America
								</li>
							</ul>
						</div>
					</div>

				</div>
			</div>
		</div>

		<div class="copy-right">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="text-center">
							<p>Designed & Developed By <a href="https://graygrids.com/" rel="nofollow" target="_blank">GrayGrids</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!--====== FOOTER PART ENDS ======-->

	<!--====== BACK TOP TOP PART START ======-->
	<a href="#" class="back-to-top btn-hover"><i class="lni lni-chevron-up"></i></a>
	<!--====== BACK TOP TOP PART ENDS ======-->


	<!--====== Bootstrap js ======-->
	<script src="assets/js/bootstrap.bundle-5.0.0.alpha-min.js"></script>

	<!--====== Tiny slider js ======-->
	<script src="assets/js/tiny-slider.js"></script>

	<!--====== wow js ======-->
	<script src="assets/js/wow.min.js"></script>

	<!--====== glightbox js ======-->
	<script src="assets/js/glightbox.min.js"></script>

	<!--====== Selectr js ======-->
	<script src="assets/js/selectr.min.js"></script>

	<!--====== Nouislider js ======-->
	<script src="assets/js/nouislider.js"></script>

	<!--====== Main js ======-->
	<script src="assets/js/main.js"></script>

	<script>
		//======== select js
		new Selectr('#sort', {
			searchable: false,
			width: 300
		});

		var snapSlider = document.getElementById('slider-snap');

			noUiSlider.create(snapSlider, {
				start: [199, 789],
				// snap: true,
				connect: true,
				range: {
					'min': 99,
					'max': 999
				}
			});

			var snapValues = [
					document.getElementById('slider-snap-value-lower'),
					document.getElementById('slider-snap-value-upper')
				];

				snapSlider.noUiSlider.on('update', function (values, handle) {
					snapValues[handle].innerHTML = values[handle]
				});
	</script>

</body>

</html>